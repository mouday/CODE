﻿using System.Windows;

namespace Miko.WPF.Tetris
{
    /// <summary>
    /// App.xaml 的交互逻辑
    /// </summary>
    public partial class App : Application
    {
    }
}
